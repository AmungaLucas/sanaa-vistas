import { useParams } from "react-router-dom";
import { useEffect, useState } from "react";
import { getPostBySlug } from "@/lib/getPostBySlug";
import { getPosts, type Post } from "@/lib/getPosts";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Clock,
  Eye,
  Heart,
  User,
  Share2,
  Bookmark,
  Facebook,
  Twitter,
  Linkedin,
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import PostCard from "@/components/PostCard";

const PostDetail = () => {
  const { slug } = useParams();
  const [post, setPost] = useState<Post | null>(null);
  const [relatedPosts, setRelatedPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [liked, setLiked] = useState(false);
  const [bookmarked, setBookmarked] = useState(false);

  useEffect(() => {
    const fetchPost = async () => {
      if (!slug) return;

      try {
        const [postData, allPosts] = await Promise.all([
          getPostBySlug(slug),
          getPosts(),
        ]);

        setPost(postData);

        if (postData) {
          const related = allPosts
            .filter(
              (p) =>
                p.id !== postData.id &&
                p.categories.some((cat) => postData.categories.includes(cat))
            )
            .slice(0, 3);
          setRelatedPosts(related);
        }
      } catch (error) {
        console.error("Error fetching post:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchPost();
  }, [slug]);

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="animate-pulse">
          <div className="h-6 bg-muted rounded w-2/3 mb-4"></div>
          <div className="h-48 bg-muted rounded mb-6"></div>
          <div className="space-y-2">
            <div className="h-3 bg-muted rounded"></div>
            <div className="h-3 bg-muted rounded w-5/6"></div>
            <div className="h-3 bg-muted rounded w-4/6"></div>
          </div>
        </div>
      </div>
    );
  }

  if (!post) {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center">
          <h1 className="font-poppins font-bold text-2xl text-heading mb-4">
            Post Not Found
          </h1>
          <p className="font-lora text-sm text-muted-foreground">
            The article you're looking for doesn't exist.
          </p>
        </div>
      </div>
    );
  }

  const formatDate = (date: Date) => {
    return date.toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  };

  // 👉 Share handler
  const handleShare = (platform: string) => {
    const url = window.location.href;
    const text = `Check out this article: ${post?.title}`;

    let shareUrl = "";

    switch (platform) {
      case "facebook":
        shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(
          url
        )}`;
        break;
      case "twitter":
        shareUrl = `https://twitter.com/intent/tweet?url=${encodeURIComponent(
          url
        )}&text=${encodeURIComponent(text)}`;
        break;
      case "linkedin":
        shareUrl = `https://www.linkedin.com/shareArticle?mini=true&url=${encodeURIComponent(
          url
        )}&title=${encodeURIComponent(post?.title || "")}`;
        break;
      case "native":
        if (navigator.share) {
          navigator
            .share({
              title: post?.title,
              text,
              url,
            })
            .catch((err) => console.error("Share failed:", err));
          return;
        } else {
          alert("Sharing not supported on this browser.");
          return;
        }
      default:
        return;
    }

    window.open(shareUrl, "_blank", "noopener,noreferrer");
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <article className="max-w-4xl mx-auto">
        {/* Article Header */}
        <div className="mb-8">
          <div className="flex flex-wrap gap-2 mb-3">
            {post.categories.map((category) => (
              <Badge key={category} variant="secondary" className="text-xs">
                {category}
              </Badge>
            ))}
          </div>

          <h1 className="font-poppins font-bold text-2xl md:text-3xl leading-snug mb-4 text-heading">
            {post.title}
          </h1>

          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3 text-xs text-muted-foreground">
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-1">
                <User className="w-3 h-3" />
                <span>{post.authorName}</span>
              </div>
              <div className="flex items-center gap-1">
                <Clock className="w-3 h-3" />
                <span>{formatDate(post.publishedAt)}</span>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="flex items-center gap-1">
                <Eye className="w-3 h-3" />
                <span>{post.views} views</span>
              </div>
              <div className="flex items-center gap-1">
                <Heart className="w-3 h-3" />
                <span>{post.likes} likes</span>
              </div>
            </div>
          </div>
        </div>

        {/* Featured Image */}
        <div className="mb-6">
          <img
            src={post.featuredImage}
            alt={post.title}
            className="w-full h-56 md:h-80 object-cover rounded-xl shadow-md"
          />
        </div>

        {/* Article Content */}
        <div className="prose max-w-none mb-6">
          <div className="font-lora text-sm leading-relaxed text-content">
            <p className="text-sm font-medium mb-4 text-muted-foreground">
              {post.excerpt}
            </p>

            <div
              className="space-y-4 text-sm"
              dangerouslySetInnerHTML={{ __html: post.content }}
            />
          </div>
        </div>

        {/* Article Actions */}
        <div className="flex flex-wrap items-center justify-between gap-3 py-4 border-t border-border">
          <div className="flex items-center gap-2">
            <Button
              variant={liked ? "default" : "outline"}
              size="sm"
              onClick={() => setLiked(!liked)}
              className={liked ? "bg-red-500 hover:bg-red-600 text-white" : ""}
            >
              <Heart className="w-3 h-3 mr-1" />
              {liked ? "Liked" : "Like"}
            </Button>

            <Button
              variant={bookmarked ? "default" : "outline"}
              size="sm"
              onClick={() => setBookmarked(!bookmarked)}
            >
              <Bookmark className="w-3 h-3 mr-1" />
              {bookmarked ? "Saved" : "Save"}
            </Button>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-muted-foreground">Share:</span>
            <Button
              size="sm"
              variant="outline"
              className="p-1"
              onClick={() => handleShare("facebook")}
            >
              <Facebook className="w-3 h-3" />
            </Button>
            <Button
              size="sm"
              variant="outline"
              className="p-1"
              onClick={() => handleShare("twitter")}
            >
              <Twitter className="w-3 h-3" />
            </Button>
            <Button
              size="sm"
              variant="outline"
              className="p-1"
              onClick={() => handleShare("linkedin")}
            >
              <Linkedin className="w-3 h-3" />
            </Button>
            <Button
              size="sm"
              variant="outline"
              className="p-1"
              onClick={() => handleShare("native")}
            >
              <Share2 className="w-3 h-3" />
            </Button>
          </div>
        </div>

        {/* Author Bio */}
        <Card className="my-8 rounded-xl shadow border border-border/50 bg-gradient-to-br from-white to-muted/20 dark:from-background dark:to-muted/5">
          <CardContent className="p-6">
            <div className="flex flex-col sm:flex-row items-center sm:items-start gap-4 text-center sm:text-left">
              <img
                src={post.authorProfilePic || "/api/placeholder/120/120"}
                alt={post.authorName}
                className="w-20 h-20 rounded-full object-cover border-2 border-white shadow"
              />

              <div className="flex-1">
                <h3 className="font-poppins font-bold text-lg text-heading mb-1">
                  {post.authorName}
                </h3>
                <span className="text-xs text-muted-foreground block mb-2">
                  Contributor & Cultural Curator
                </span>
                <p className="font-lora text-xs text-content mb-4 leading-relaxed">
                  {post.authorAbout ||
                    "Passionate writer and cultural curator documenting Kenya's vibrant creative scene."}
                </p>

                <div className="flex flex-wrap justify-center sm:justify-start gap-2">
                  <Button
                    variant="default"
                    size="sm"
                    className="px-4 py-1 rounded-full text-xs"
                  >
                    Follow Author
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="px-4 py-1 rounded-full text-xs"
                  >
                    View Profile
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </article>

      {/* Related Posts */}
      {relatedPosts.length > 0 && (
        <section className="mt-10">
          <h2 className="font-poppins font-bold text-lg text-heading mb-6">
            Related Articles
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {relatedPosts.map((relatedPost) => (
              <PostCard key={relatedPost.id} post={relatedPost} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
};

export default PostDetail;
